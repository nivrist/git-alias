package com.siman.nilo.rubik.wa.model.nilotfn;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "als_rubik_c_and_c")
public class AlsRubikCandC {
	
	@Id
	@Column(name = "ID")
	private Integer id;
	
	@Column(name = "ID_J_C")
	private String IdjC;
	
	@Column(name = "NUM_PEDIDO")
	private String numPedido;
	
	@Column(name = "NUMERO_DOCUMENTO")
	private String numeroDocumento;
	
	@Column(name = "TELEFONO")
	private String telefono;
	
	@Column(name = "NOMBRE_COMPLETO")
	private String nombreCompleto;
	
	@Column(name = "PAIS")
	private String pais;
	
	@Column(name = "SISTEMA")
	private String sistema;
	
	@Column(name = "NOTIFICADO")
	private Integer notificado;
	
	@Column(name = "SUCURSAL_ENTREGA")
	private String sucursalEntrega;
	
	
	@Column(name = "FECHA_NOTIFICACION")
	private Date fechaNotificacion;
	
	
	@Column(name = "FECHA_REENVIO_NOTIFICACION")
	private Date fechaReenvioNotificacion;
	
	@Column(name = "ENVIO")
	private String envio;
	
	@Column(name = "FECHA_PEDIDO")
	private Date fechaPedido;
	
	@Column(name = "TIPO_ENVIO")
	private String tipoEnvio;
	
	@Column(name = "load_rubik_shp")
	private Integer loadRubikShp;
	
	@Column(name = "id_estado")
	private Integer idEstado;
	
	@Column(name = "id_tienda")
	private String idTienda;
	
	@Column(name = "estado_notifi_ws")
	private String estadoNotifiWs;
	



	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getIdjC() {
		return IdjC;
	}


	public void setIdjC(String idjC) {
		IdjC = idjC;
	}


	public String getNumPedido() {
		return numPedido;
	}


	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}


	public String getNumeroDocumento() {
		return numeroDocumento;
	}


	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}


	public String getTelefono() {
		return telefono;
	}


	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}


	public String getNombreCompleto() {
		return nombreCompleto;
	}


	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}


	public String getPais() {
		return pais;
	}


	public void setPais(String pais) {
		this.pais = pais;
	}


	public String getSistema() {
		return sistema;
	}


	public void setSistema(String sistema) {
		this.sistema = sistema;
	}


	public Integer getNotificado() {
		return notificado;
	}


	public void setNotificado(Integer notificado) {
		this.notificado = notificado;
	}


	public String getSucursalEntrega() {
		return sucursalEntrega;
	}


	public void setSucursalEntrega(String sucursalEntrega) {
		this.sucursalEntrega = sucursalEntrega;
	}


	public Date getFechaNotificacion() {
		return fechaNotificacion;
	}


	public void setFechaNotificacion(Date fechaNotificacion) {
		this.fechaNotificacion = fechaNotificacion;
	}


	public Date getFechaReenvioNotificacion() {
		return fechaReenvioNotificacion;
	}


	public void setFechaReenvioNotificacion(Date fechaReenvioNotificacion) {
		this.fechaReenvioNotificacion = fechaReenvioNotificacion;
	}


	public String getEnvio() {
		return envio;
	}


	public void setEnvio(String envio) {
		this.envio = envio;
	}


	public Date getFechaPedido() {
		return fechaPedido;
	}


	public void setFechaPedido(Date fechaPedido) {
		this.fechaPedido = fechaPedido;
	}


	public String getTipoEnvio() {
		return tipoEnvio;
	}


	public void setTipoEnvio(String tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}


	public Integer getLoadRubikShp() {
		return loadRubikShp;
	}


	public void setLoadRubikShp(Integer loadRubikShp) {
		this.loadRubikShp = loadRubikShp;
	}


	public Integer getIdEstado() {
		return idEstado;
	}


	public void setIdEstado(Integer idEstado) {
		this.idEstado = idEstado;
	}


	public String getIdTienda() {
		return idTienda;
	}


	public void setIdTienda(String idTienda) {
		this.idTienda = idTienda;
	}


	public String getEstadoNotifiWs() {
		return estadoNotifiWs;
	}


	public void setEstadoNotifiWs(String estadoNotifiWs) {
		this.estadoNotifiWs = estadoNotifiWs;
	}
	
	
	
	

}
