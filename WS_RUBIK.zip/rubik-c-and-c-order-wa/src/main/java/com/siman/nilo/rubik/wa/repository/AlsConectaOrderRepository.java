package com.siman.nilo.rubik.wa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;

import com.siman.nilo.rubik.wa.model.nilotfn.AlsConectaOrder;



@Repository
public interface AlsConectaOrderRepository extends JpaRepository<AlsConectaOrder, Integer>{

	@Query(nativeQuery = true, value = "select  nvl(max(id)+1,1) from ALS_CONECTA_ORDER")
    public int nextId();
	
	
	 @Procedure("PR_load_order_by_janis")
	 public void execLoadJanis();
	 
	 
	 @Procedure("PR_load_order_by_conecta")
	 public void execLoadConecta();
	
}
