package com.siman.nilo.rubik.wa.service;








import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.siman.nilo.rubik.wa.client.RubikOrderClient;
import com.siman.nilo.rubik.wa.model.nilotfn.AlsRubikCandC;
import com.siman.nilo.rubik.wa.model.nilotfn.AlsRubikSignature;
import com.siman.nilo.rubik.wa.repository.AlsConectaOrderRepository;
import com.siman.nilo.rubik.wa.repository.AlsParamCandCRepository;
import com.siman.nilo.rubik.wa.repository.AlsRubikCandCRepository;
import com.siman.nilo.rubik.wa.repository.AlsRubikSignatureRepository;
import com.siman.nilo.rubik.wa.utils.Data;
import com.siman.nilo.rubik.wa.utils.DataFirma;
import com.siman.nilo.rubik.wa.utils.ResponseTransaction;
import com.siman.nilo.rubik.wa.utils.ResponseTransactionFirma;
import com.siman.nilo.rubik.wa.utils.ResponseTransactionSignature;

@Service
public class RubikOrderService {

	Logger logger = LoggerFactory.getLogger(RubikOrderService.class);

	
	
	@Autowired
	RubikOrderClient rubikOrderClient;
	
	@Autowired
	AlsParamCandCRepository alsParamCandCRepository;

	@Autowired
	AlsRubikSignatureRepository alsRubikSignatureRepository;
	
	@Autowired
	AlsConectaOrderRepository alsConectaOrderRepository;

	
	@Autowired
	AlsRubikCandCRepository alsRubikCandCRepository;
	
	
	
	
	public ResponseTransaction getOrder(String numOrder) {
		
		ResponseTransaction res = new ResponseTransaction();
		Data orderData =  new Data();
		try {
		
	    AlsRubikCandC data = alsRubikCandCRepository.getOrder(numOrder);
	    if(data!=null) {
	    orderData.setTienda(data.getSucursalEntrega());
	    orderData.setEnvio(data.getEnvio());
	    orderData.setEstado(data.getEstadoNotifiWs());
	    orderData.setNombreCliente(data.getNombreCompleto());
	    orderData.setNumeroTelefonico(data.getTelefono());
	    orderData.setNumOrden(data.getNumPedido());	   
	    orderData.setIdEstado(data.getIdEstado());
	    orderData.setIdTienda(data.getIdTienda());	
	    orderData.setPais(data.getPais());
	    orderData.setSistema(data.getSistema());
		res.setStatus(String.valueOf(200));		
		res.setData(orderData);
	    }else {
	    	res.setStatus(String.valueOf(404));		
			res.setData(orderData);
	    }
		
		}catch(Exception e) {
			res.setStatus(String.valueOf(500));
			res.setData(orderData);
			e.printStackTrace();
		}
		return res;
	}
	
	public ResponseTransactionSignature saveSignature(String numOrder, String numDoc, String clientName, String country,
			String signature) {
		ResponseTransactionSignature resp = new ResponseTransactionSignature();
		try {
			
			AlsRubikSignature sig = new AlsRubikSignature();
			sig.setClientName(clientName);
			sig.setCountry(country);
			sig.setCreatedDate(new Date());
			sig.setId(alsRubikSignatureRepository.nextId());
			sig.setNumDoc(numDoc);
			sig.setNumOrder(numOrder);
			sig.setSiganture(signature);
			alsRubikSignatureRepository.save(sig);
			resp.setMsg("Datos guardados..!");
			resp.setStatus("200");
		} catch (Exception ex) {
			
			resp.setMsg("Error al intentar guardar datos: " + ex.getMessage());
			resp.setStatus("500");

		}

		return resp;
	}
	
public ResponseTransactionFirma getOrderFirma(String numOrder) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		ResponseTransactionFirma res = new ResponseTransactionFirma();
		DataFirma orderData =  new DataFirma();
		try {
		
	    AlsRubikCandC data = alsRubikCandCRepository.getOrder(numOrder);
	    if(data!=null) {
	    orderData.setTienda(data.getSucursalEntrega());
	    orderData.setEnvio(data.getEnvio());
	    orderData.setEstado("Listo para Retirar");
	    orderData.setNombreCliente(data.getNombreCompleto());
	    orderData.setNumeroTelefonico(data.getTelefono());
	    orderData.setNumOrden(data.getNumPedido());
	    orderData.setNumDocu(data.getNumeroDocumento());
	    orderData.setPais(data.getPais());
	    orderData.setTipoEnvio(data.getTipoEnvio());
	    orderData.setFechaPedido((data.getFechaPedido()!=null?sdf.format(data.getFechaPedido().getTime()):""));
		res.setStatus(String.valueOf(200));		
		res.setData(orderData);
	    }else {
	    	res.setStatus(String.valueOf(200));		
			res.setData(orderData);
	    }
		
		}catch(Exception e) {
			res.setStatus(String.valueOf(500));
			res.setData(orderData);
			e.printStackTrace();
		}
		return res;
	}

	

	

	

}
