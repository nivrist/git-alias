package com.siman.nilo.rubik.wa.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;


@FeignClient(contextId = "RubikOrderClient",url="https://alsicorp.sharepoint.com/sites", name="get")
public interface RubikOrderClient {
	
	@GetMapping(path = "/{siteCountry}/_api/Web/Lists/getbytitle('{listCountry}')/Items?$select={defaultselect}&$filter={defaultfilter}", consumes = "application/json;odata=verbose", produces = "application/json;odata=verbose")
	String getOrderConectaByCountry(@PathVariable("defaultselect") String defaultselected , @PathVariable("defaultfilter") String deffilter , @RequestHeader("Accept") String accept,@RequestHeader("Content-Type") String type,@RequestHeader("Authorization") String auth , @PathVariable("siteCountry") String siteByCountry , @PathVariable("listCountry") String listByCoutry);
	
	
	
}
