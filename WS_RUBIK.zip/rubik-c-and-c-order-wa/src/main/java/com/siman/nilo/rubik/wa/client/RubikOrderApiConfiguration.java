package com.siman.nilo.rubik.wa.client;


import feign.RequestInterceptor;
import feign.RequestTemplate;


public class RubikOrderApiConfiguration implements RequestInterceptor {

	
	
	
	@Override
	public void apply(RequestTemplate template) {
		
	}
}
