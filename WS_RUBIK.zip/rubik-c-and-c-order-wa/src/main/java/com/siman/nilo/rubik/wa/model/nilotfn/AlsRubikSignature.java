package com.siman.nilo.rubik.wa.model.nilotfn;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "als_rubik_signature")
public class AlsRubikSignature {
	
	
	@Id
	@Column(name = "ID")
	private Integer id;
	
	@Column(name = "NUM_ORDER")
	private String numOrder;
	
	@Column(name = "NUM_DOC")
	private String numDoc;
	
	@Column(name = "CLIENT_NAME")
	private String clientName;
	
	@Column(name = "COUNTRY")
	private String country;
	
	@Lob
	@Column(name = "SIGNATURE")
	private String siganture;
	
	@Column(name = "CREATED_DATE")
	private Date createdDate;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNumOrder() {
		return numOrder;
	}
	public void setNumOrder(String numOrder) {
		this.numOrder = numOrder;
	}
	public String getNumDoc() {
		return numDoc;
	}
	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getSiganture() {
		return siganture;
	}
	public void setSiganture(String siganture) {
		this.siganture = siganture;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	

}
