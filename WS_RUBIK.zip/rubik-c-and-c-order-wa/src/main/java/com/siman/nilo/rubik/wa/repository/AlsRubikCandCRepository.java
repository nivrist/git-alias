package com.siman.nilo.rubik.wa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.siman.nilo.rubik.wa.model.nilotfn.AlsRubikCandC;

@Repository
public interface AlsRubikCandCRepository extends JpaRepository<AlsRubikCandC, Integer> {
	
	@Query(nativeQuery=true , value="select a.* from  als_rubik_c_and_c a where num_pedido = ?")
	public AlsRubikCandC getOrder(String numOrder); 
	

}
