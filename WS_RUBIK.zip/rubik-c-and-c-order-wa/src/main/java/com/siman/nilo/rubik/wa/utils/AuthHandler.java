package com.siman.nilo.rubik.wa.utils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class AuthHandler {

    

    public String authenticate(String clientIdDb, String secretPassDb , String tenantid,String ressourceId) {
        CloseableHttpClient httpClient = HttpClients.createDefault();

       // Pair<String, String> bearerRealmAndRessourceId = getBearerRealmAndRessourceId(httpClient);
        //String bearerRealm = bearerRealmAndRessourceId.getFirst();
        //String ressourceId = bearerRealmAndRessourceId.getSecond();

        String bearerToken = getBearerToken(tenantid, ressourceId, httpClient,clientIdDb,secretPassDb);
        return bearerToken;
    }

    private String getBearerToken(String bearerRealm, String ressourceId, CloseableHttpClient httpClient , String clientIdDb , String secretPassDb) {
        String url = String.format("https://accounts.accesscontrol.windows.net/%s/tokens/OAuth/2", bearerRealm);

        HttpPost postRequest = new HttpPost(url);
        postRequest.setHeader("Content-Type", "application/x-www-form-urlencoded");

        String clientId = String.format("%s@%s", clientIdDb, bearerRealm);
        String resource = String.format("%s/%s@%s", ressourceId, "alsicorp.sharepoint.com", bearerRealm);
        List<NameValuePair> params =   new ArrayList<>();
        params.add( new BasicNameValuePair("grant_type", "client_credentials"));
        params.add( new BasicNameValuePair("client_id", clientId));
        params.add( new BasicNameValuePair("client_secret", secretPassDb));
        params.add( new BasicNameValuePair("resource", resource));
        

        try {
            postRequest.setEntity(new UrlEncodedFormEntity(params));
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("Parámetro con formato incorrecto", e);
        }

        try  {
            HttpResponse response = httpClient.execute(postRequest);

            String bodyJson = IOUtils.toString(response.getEntity().getContent(), "UTF-8");
            JsonObject convertedObject = null;
			try {
				convertedObject = new Gson().fromJson(bodyJson, JsonObject.class);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            String bearerToken = null;
			try {
				bearerToken = convertedObject.get("access_token").getAsString();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
            return bearerToken;
        } catch (IOException e) {
        	e.printStackTrace();
            throw new RuntimeException("La solicitud de publicación para obtener el token de portador falló", e);
        }
    }

    
    
        
}