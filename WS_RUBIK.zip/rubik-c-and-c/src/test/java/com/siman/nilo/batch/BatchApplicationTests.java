package com.siman.nilo.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchApplicationTests {

	@Test
	void contextLoads() {
		
		
	System.out.println("Test");
	}
	
	

}
