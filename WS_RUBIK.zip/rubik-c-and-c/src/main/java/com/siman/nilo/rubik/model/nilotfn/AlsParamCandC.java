package com.siman.nilo.rubik.model.nilotfn;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "als_param_c_and_c")
public class AlsParamCandC {
	
	
	@Id
	@Column(name = "KEY_VAL")
	private String keyVal;
	
	
	@Column(name = "VAL")
	private String val;


	public String getKeyVal() {
		return keyVal;
	}


	public void setKeyVal(String keyVal) {
		this.keyVal = keyVal;
	}


	public String getVal() {
		return val;
	}


	public void setVal(String val) {
		this.val = val;
	}

}
