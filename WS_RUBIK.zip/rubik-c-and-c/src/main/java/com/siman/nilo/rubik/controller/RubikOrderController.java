package com.siman.nilo.rubik.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.siman.nilo.rubik.service.RubikOrderService;
import com.siman.nilo.rubik.utils.ResponseTransaction;


@RestController
@RequestMapping("/Order")
public class RubikOrderController {
	
	Logger logger = LoggerFactory.getLogger(RubikOrderController.class);
	
	@Autowired
	RubikOrderService rubikOrderService;	
	
	
	@GetMapping("/getOrderDelivered")
	public ResponseEntity<?>  findAllPmoda(){
		ResponseTransaction SkuListJson = new ResponseTransaction();
		return ResponseEntity.status(200).body(SkuListJson);
	}
	
	
	@GetMapping("/OrderConectaSV")
	public ResponseEntity<?>  getOrderConectaSV(){			
		ResponseTransaction  token = rubikOrderService.getResponseOrderByCountry("SV");
		return ResponseEntity.status(Integer.parseInt(token.getEstado())).body(token);
	}
	
	@GetMapping("/OrderConectaGT")
	public ResponseEntity<?>  getOrderConectaGT(){			
		ResponseTransaction  token = rubikOrderService.getResponseOrderByCountry("GT");
		return ResponseEntity.status(Integer.parseInt(token.getEstado())).body(token);
	}
	
	@GetMapping("/OrderConectaCR")
	public ResponseEntity<?>  getOrderConectaCR(){			
		ResponseTransaction  token = rubikOrderService.getResponseOrderByCountry("CR");
		return ResponseEntity.status(Integer.parseInt(token.getEstado())).body(token);
	}
	
	
	@GetMapping("/OrderConectaNI")
	public ResponseEntity<?>  getOrderConectaNI(){			
		ResponseTransaction  token = rubikOrderService.getResponseOrderByCountry("NI");
		return ResponseEntity.status(Integer.parseInt(token.getEstado())).body(token);
	}
	
		
	@GetMapping("/LoadOrderJanis")
	public ResponseEntity<?>  getLoadOrderJanis(){			
		ResponseTransaction  token = rubikOrderService.loadOrderJanis();
		return ResponseEntity.status(Integer.parseInt(token.getEstado())).body(token);
	}
	
	
	@GetMapping("/LoadOrderConecta")
	public ResponseEntity<?>  getLoadOrderConecta(){			
		ResponseTransaction  token = rubikOrderService.loadOrderConecta();
		return ResponseEntity.status(Integer.parseInt(token.getEstado())).body(token);
	}
	
	
	@GetMapping("/send_wa")
	public ResponseEntity<?>  getCookie(){			
		ResponseTransaction  token = rubikOrderService.send_WhatsApp();
		return ResponseEntity.status(Integer.parseInt(token.getEstado())).body(token);
	}
	
	@GetMapping("/created_rubik_list")
	public ResponseEntity<?>  createdRubikList(){			
		ResponseTransaction  token = rubikOrderService.createdRubikList("SV");
		return ResponseEntity.status(Integer.parseInt(token.getEstado())).body(token);
	}
	
	
}
