package com.siman.nilo.rubik.utils;

import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class Utils {

	Logger logger = LoggerFactory.getLogger(Utils.class);

	@Value("${vtex.vtex_retryable_errors}")
	private String vtexRetryableErrors;
	
	@Value("${auth.passphrase}")
	private String passphrase;

	public boolean checkRetryableException(String respDesc) {
		boolean isRetryable = false;
		String errors[] = vtexRetryableErrors.split(",");
		for (int i = 0; i < errors.length; i++) {
			if (respDesc.contains(errors[i])) {
				isRetryable = true;
			}
		}
		return isRetryable;
	}
	
	public Boolean checkPassphrase(String token) {
		try {
			byte[] decodedToken = Base64.getDecoder().decode(token);
			return passphrase.equals(new String(decodedToken));
		} catch(Exception e) {
			logger.error("No se pudo decodificar el token: " + e);
		}
		
		return false;
	}
}
