package com.siman.nilo.rubik.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.siman.nilo.rubik.model.nilotfn.AlsRubikCandC;


@Repository
public interface AlsRubikCandCReporsitory extends JpaRepository<AlsRubikCandC, Integer>{

	@Query(nativeQuery=true , value="select * from  als_rubik_c_and_c where notificado in (0,2)")
	public List<AlsRubikCandC> getOrderSend();
	
	@Query(nativeQuery=true , value="select * from  als_rubik_c_and_c where load_rubik_shp=0")
	public List<AlsRubikCandC> getOrderLoad();
	
}
