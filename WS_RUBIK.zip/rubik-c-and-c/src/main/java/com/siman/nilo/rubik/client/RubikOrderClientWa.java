package com.siman.nilo.rubik.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



@FeignClient(contextId = "RubikOrderClientWa",url="https://tickets.bitworks.com.sv/ApiEnvio", name="get")
public interface RubikOrderClientWa {
	
	
	
	@RequestMapping(method = RequestMethod.POST ,path = "/cuenta/Login",consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	ResponseEntity<Object> getCookie( @RequestHeader("Content-Type") String type,@RequestHeader("tiporequest") String auth , @RequestParam(name = "usuario") String  usuario , @RequestParam(name = "contrasena") String contrasena, @RequestBody String body );
	
	
	@RequestMapping(method = RequestMethod.POST ,path = "/Whatsapp/EnviarMensaje",produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Object> send_messageWa(@RequestHeader("Host") String host , @RequestHeader("Cookie") String cookie , @RequestBody String body);

	
	

}
