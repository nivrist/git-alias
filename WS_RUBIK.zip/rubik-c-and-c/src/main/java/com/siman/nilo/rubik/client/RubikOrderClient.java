package com.siman.nilo.rubik.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@FeignClient(contextId = "RubikOrderClient",url="https://alsicorp.sharepoint.com/sites", name="get")
public interface RubikOrderClient {
	
	@GetMapping(path = "/{siteCountry}/_api/Web/Lists/getbytitle('{listCountry}')/Items?$select={defaultselect}&$filter={defaultfilter}", consumes = "application/json;odata=verbose", produces = "application/json;odata=verbose")
	String getOrderConectaByCountry(@PathVariable("defaultselect") String defaultselected , @PathVariable("defaultfilter") String deffilter , @RequestHeader("Accept") String accept,@RequestHeader("Content-Type") String type,@RequestHeader("Authorization") String auth , @PathVariable("siteCountry") String siteByCountry , @PathVariable("listCountry") String listByCoutry);
	
	@RequestMapping(method = RequestMethod.POST ,path = "/VentasporWhatsAppSV2/_api/Web/Lists/getbytitle('RubikCandC')/Items",consumes = "application/json;odata=verbose")
	String createdSharepointListRubik(@RequestBody String body,@RequestHeader("Authorization") String auth);


}
