package com.siman.nilo.rubik.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.siman.nilo.rubik.model.nilotfn.AlsParamCandC;

@Repository
public interface AlsParamCandCRepository  extends JpaRepository<AlsParamCandC, String>{

	@Query(nativeQuery = true, value = "select val from  als_param_c_and_c a where key_val= ? ")
    public String getVal(String keyVal);
	
}
