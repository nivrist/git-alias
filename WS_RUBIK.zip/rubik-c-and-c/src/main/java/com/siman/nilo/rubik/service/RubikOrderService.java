package com.siman.nilo.rubik.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.siman.nilo.rubik.client.RubikOrderClient;
import com.siman.nilo.rubik.client.RubikOrderClientWa;
import com.siman.nilo.rubik.model.nilotfn.AlsConectaOrder;
import com.siman.nilo.rubik.model.nilotfn.AlsRubikCandC;
import com.siman.nilo.rubik.repository.AlsConectaOrderRepository;
import com.siman.nilo.rubik.repository.AlsParamCandCRepository;
import com.siman.nilo.rubik.repository.AlsRubikCandCReporsitory;
import com.siman.nilo.rubik.utils.AuthHandler;
import com.siman.nilo.rubik.utils.ResponseTransaction;
import com.siman.nilo.rubik.utils.TemplateTigo;
import feign.FeignException;

@Service
public class RubikOrderService {

	Logger logger = LoggerFactory.getLogger(RubikOrderService.class);

	@Autowired
	RubikOrderClient rubikOrderClient;

	@Autowired
	RubikOrderClientWa rubikOrderClientWa;

	@Autowired
	AlsRubikCandCReporsitory alsRubikCandCReporsitory;

	@Autowired
	AlsParamCandCRepository alsParamCandCRepository;

	@Autowired
	AlsConectaOrderRepository alsConectaOrderRepository;

	public String payLoad(String namespace, String name, String cliente, String numeOrden, String sucuEntrega,
			String telefono, String token) {

		String payLoadLogin = "{\"template\":{\"namespace\":\"{namespace}\",\"language\":{\"code\":\"ES\"},\"name\":\"{name}\",\"components\":[{\"type\":\"body\",\"parameters\":[{\"text\":\"{cliente}\",\"type\":\"text\"},{\"text\":\"{numeOrden}\",\"type\":\"text\"},{\"text\":\"{sucuEntrega}\",\"type\":\"text\"}]}]},\"to\":\"{telefono}\",\"token\":\"{token}\"}";

		return payLoadLogin.replace("{namespace}", namespace).replace("{name}", name).replace("{cliente}", cliente)
				.replace("{numeOrden}", numeOrden).replace("{sucuEntrega}", sucuEntrega).replace("{telefono}", telefono)
				.replace("{token}", token);
	}

	public void notificarWa(AlsRubikCandC send, String cookiesauth) {

		ResponseEntity<Object> sendWa = null;
		String jsonString = alsParamCandCRepository.getVal((send.getPais().equals("SV") ? "TIGO_TEMPLATE_SV"
				: send.getPais().equals("GT") ? "TIGO_TEMPLATE_GT"
						: send.getPais().equals("CR") ? "TIGO_TEMPLATE_CR" : "TIGO_TEMPLATE_NI"));
		Gson g = new Gson();
		TemplateTigo s = g.fromJson(jsonString, TemplateTigo.class);
		String messagePayload = payLoad(s.getNamespace(), s.getName(), send.getNombreCompleto(), send.getNumPedido(),
				send.getSucursalEntrega(), send.getTelefono(), s.getToken());

		try {
			sendWa = rubikOrderClientWa.send_messageWa("tickets.bitworks.com.sv", cookiesauth, messagePayload);

			if (sendWa.getStatusCodeValue() == 200) {
				if (send.getNotificado().equals("2")) {// cuando el mensaje es un reenvio
					send.setFechaReenvioNotificacion(new Date());
					send.setNotificado("1");
				} else {
					send.setNotificado("1");
					send.setFechaNotificacion(new Date());
				}

			} else {

				send.setNotificado("3");// cuando se genera error en el request
				send.setFechaNotificacion(new Date());

			}
			alsRubikCandCReporsitory.save(send);
		} catch (FeignException ex) {

			send.setNotificado("3");// cuando se genera error en el request
			send.setFechaNotificacion(new Date());
			alsRubikCandCReporsitory.save(send);
			ex.printStackTrace();
		}

	}

	public ResponseTransaction send_WhatsApp() {
		ResponseTransaction res = new ResponseTransaction();
		String notificar = alsParamCandCRepository.getVal("SEND_WA");
		if (notificar.equals("1")) {
			List<String> headerFieldValue = new ArrayList<>();
			ResponseEntity<Object> cookie = rubikOrderClientWa.getCookie("application/x-www-form-urlencoded", "movil",
					"SimanEnvios", "9nZ9FNE3", "{}");
			HttpHeaders he = cookie.getHeaders();
			Set<Entry<String, List<String>>> entrySet = he.entrySet();
			for (Entry<String, List<String>> e : entrySet) {
				if (e.getKey().contains("set-cookie")) {
					headerFieldValue = e.getValue();
				}
			}

			String cookiesauth = "";
			for (String headerValue : headerFieldValue) {
				if (headerValue.startsWith(".ASPXAUTH=")) {
					cookiesauth = headerValue;
				}
			}
			List<AlsRubikCandC> listaEnvio = alsRubikCandCReporsitory.getOrderSend();
			for (AlsRubikCandC send : listaEnvio) {

				notificarWa(send, cookiesauth);
			}

		}
		res.setEstado(String.valueOf(200));
		res.setMensaje("Request ejecutado con exito..");
		return res;

	}

	public String payLoadForRubikList(String title, int id_j_c, String num_pedido, String numero_documento,
			String telefono, String nombre_completo, String pais, String sistema, String notificado,
			String sucursal_entrega, String envio, String fecha_pedido, String tipo_envio) {
		String payLoadBody = "{\"__metadata\": {\"type\": \"SP.Data.RubikCandCListItem\"},\n" + "        \"Title\": \""
				+ title + "\",\n" + "        \"id_j_c\":" + id_j_c + ",\n" + "        \"num_pedido\":\"" + num_pedido
				+ "\",\n" + "        \"numero_documento\":\"" + numero_documento + "\",\n" + "        \"telefono\":\""
				+ telefono + "\",\n" + "        \"nombre_completo\":\"" + nombre_completo + "\",\n"
				+ "        \"pais\":\"" + pais + "\",\n" + "        \"sistema\":\"" + sistema + "\",\n"
				+ "        \"notificado\":\"" + notificado + "\",\n" + "        \"sucursal_entrega\":\""
				+ sucursal_entrega + "\",\n" + "        \"envio\":\"" + envio + "\",\n" + "        \"fecha_pedido\":\""
				+ fecha_pedido + "\",\n" + "        \"tipo_envio\":\"" + tipo_envio + "\"\n" + "\n" + " }";

		return payLoadBody;

	}

	public void loadShp(String Token, AlsRubikCandC dto) {
		try {
			String bodyJson = "";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String payload = payLoadForRubikList(String.valueOf(dto.getId()), Integer.parseInt(dto.getIdJc()),
					dto.getNumPedido(), dto.getNumeroDocumento(), dto.getTelefono(), dto.getNombreCompleto(),
					dto.getPais(), dto.getSistema(), dto.getNotificado(), dto.getSucursalEntrega(), dto.getEnvio(),
					(dto.getFechaPedido() != null ? sdf.format(dto.getFechaPedido().getTime()) : ""),
					dto.getTipoEnvio());
			bodyJson = rubikOrderClient.createdSharepointListRubik(payload, "Bearer " + Token);
			dto.setLoadRubikShp(1);
			alsRubikCandCReporsitory.save(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public ResponseTransaction createdRubikList(String pais) {
		ResponseTransaction res = new ResponseTransaction();
		AuthHandler Auth = new AuthHandler();
		try {
			String clientIdByCountry = alsParamCandCRepository.getVal("CONECTA_KEY_SV");
			String secretPassByCountry = alsParamCandCRepository.getVal("CONECTA_KEY_PASS_SV");
			String tenantId = alsParamCandCRepository.getVal("CONECTA_TENANT_ID");
			String resourcesID = alsParamCandCRepository.getVal("CONECTA_RESOURCES_ID");
			String Token = Auth.authenticate(clientIdByCountry, secretPassByCountry, tenantId, resourcesID);
			List<AlsRubikCandC> list = alsRubikCandCReporsitory.getOrderLoad();
			for (AlsRubikCandC ent : list) {
				loadShp(Token, ent);
			}

			res.setEstado(String.valueOf(200));
			res.setMensaje("Request ejecutado con exito..");
		} catch (Exception e) {
			res.setEstado(String.valueOf(500));
			res.setMensaje(e.getLocalizedMessage());
			e.printStackTrace();
		}

		return res;
	}

	public ResponseTransaction getResponseOrderByCountry(String pais) {
		ResponseTransaction res = new ResponseTransaction();
		AuthHandler Auth = new AuthHandler();
		try {
			String bodyJson = "";
			String tenantId = alsParamCandCRepository.getVal("CONECTA_TENANT_ID");
			String resourcesID = alsParamCandCRepository.getVal("CONECTA_RESOURCES_ID");
			String secretPassByCountry = alsParamCandCRepository.getVal((pais.equals("SV") ? "CONECTA_KEY_PASS_SV"
					: pais.equals("GT") ? "CONECTA_KEY_PASS_GT"
							: pais.equals("CR") ? "CONECTA_KEY_PASS_CR" : "CONECTA_KEY_PASS_NI"));
			String clientIdByCountry = alsParamCandCRepository.getVal((pais.equals("SV") ? "CONECTA_KEY_SV"
					: pais.equals("GT") ? "CONECTA_KEY_GT" : pais.equals("CR") ? "CONECTA_KEY_CR" : "CONECTA_KEY_NI"));
			String listaPais = alsParamCandCRepository.getVal((pais.equals("SV") ? "CONECTA_LISTA_SV"
					: pais.equals("GT") ? "CONECTA_LISTA_GT"
							: pais.equals("CR") ? "CONECTA_LISTA_CR" : "CONECTA_LISTA_NI"));
			String defaulSelected = alsParamCandCRepository.getVal("CONECTA_DEFAULT_SELECTED");
			String defaultFilter = alsParamCandCRepository.getVal("CONECTA_DEFAULT_FILTER");
			String sharepointSiteByCountry = alsParamCandCRepository.getVal((pais.equals("SV") ? "CONECTA_SITE_SV"
					: pais.equals("GT") ? "CONECTA_SITE_GT"
							: pais.equals("CR") ? "CONECTA_SITE_CR" : "CONECTA_SITE_NI"));
			String Token = Auth.authenticate(clientIdByCountry, secretPassByCountry, tenantId, resourcesID);
			bodyJson = rubikOrderClient.getOrderConectaByCountry(defaulSelected, defaultFilter,
					"application/json;odata=verbose", "application/json;odata=verbose", "Bearer " + Token,
					sharepointSiteByCountry, listaPais);
			AlsConectaOrder order = new AlsConectaOrder();
			order.setConectOrderData(bodyJson);
			order.setEstatusApi(String.valueOf(200));
			order.setPais(pais);
			order.setProcesado(0);
			order.setId(alsConectaOrderRepository.nextId());
			alsConectaOrderRepository.save(order);
			res.setEstado(String.valueOf(200));
			res.setMensaje("Request ejecutado con exito..");
		} catch (Exception e) {
			res.setEstado(String.valueOf(500));
			res.setMensaje(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return res;
	}

	public ResponseTransaction loadOrderJanis() {

		ResponseTransaction res = new ResponseTransaction();
		try {

			alsConectaOrderRepository.execLoadJanis();
			createdRubikList("SV");// se cargan todas las ordenes a la lista de SharePoint para evitar usar el
									// compoenete Custom
			res.setEstado("200");
			res.setMensaje("Proceso PR_load_order_by_janis ejecutado con exito...");
		} catch (Exception e) {
			res.setEstado("500");
			res.setMensaje("Se genero un error al intentar realizar ejecutar el proceso PR_load_order_by_janis : "
					+ e.getMessage());
			e.printStackTrace();
		}

		return res;

	}

	public ResponseTransaction loadOrderConecta() {

		ResponseTransaction res = new ResponseTransaction();
		try {

			alsConectaOrderRepository.execLoadConecta();
			createdRubikList("SV");// se cargan todas las ordenes a la lista de SharePoint para evitar usar el
									// compoenete Custom
			res.setEstado("200");
			res.setMensaje("Proceso PR_load_order_by_conecta ejecutado con exito...");
		} catch (Exception e) {
			res.setEstado("500");
			res.setMensaje("Se genero un error al intentar realizar ejecutar el proceso PR_load_order_by_conecta : "
					+ e.getMessage());
			e.printStackTrace();
		}

		return res;

	}

}
