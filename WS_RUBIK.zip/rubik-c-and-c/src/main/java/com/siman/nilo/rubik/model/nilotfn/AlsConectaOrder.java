package com.siman.nilo.rubik.model.nilotfn;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ALS_CONECTA_ORDER")
public class AlsConectaOrder {	
	
	@Id
	@Column(name = "ID")
	private Integer id;

	@Column(name = "CONECTA_ORDER_DATA")
	private String conectOrderData;
	
	@Column(name = "PAIS")
	private String pais;
	
	@Column(name = "PROCESADO")
	private Integer procesado;

	@Column(name = "ESTATUS_API")
	private String estatusApi;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getConectOrderData() {
		return conectOrderData;
	}

	public void setConectOrderData(String conectOrderData) {
		this.conectOrderData = conectOrderData;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public Integer getProcesado() {
		return procesado;
	}

	public void setProcesado(Integer procesado) {
		this.procesado = procesado;
	}

	public String getEstatusApi() {
		return estatusApi;
	}

	public void setEstatusApi(String estatusApi) {
		this.estatusApi = estatusApi;
	}
	
	
	
	
}
