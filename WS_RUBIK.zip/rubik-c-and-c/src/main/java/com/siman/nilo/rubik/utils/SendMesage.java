package com.siman.nilo.rubik.utils;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.util.SystemPropertyUtils;

public class SendMesage {

	
	static String payLoadLogin = "{\r\n" + 
			"\"template\":\r\n" + 
			"{\r\n" + 
			"\"namespace\":\"44d9df4c_9708_4f76_9f8b_e4bc3a6cfad2\",\r\n" + 
			"\"language\":\r\n" + 
			"{\r\n" + 
			"\"code\":\"ES\"\r\n" + 
			"},\r\n" + 
			"\"name\":\"pedidolisto1\",\r\n" + 
			"\"components\":\r\n" + 
			"[\r\n" + 
			"{\r\n" + 
			"\"type\":\"body\",\r\n" + 
			"\"parameters\":\r\n" + 
			"[\r\n" + 
			"{\r\n" + 
			"\"text\":\"Julio Panameño\",\r\n" + 
			"\"type\":\"text\"\r\n" + 
			"},\r\n" + 
			"{\r\n" + 
			"\"text\":\"1083765-45\",\r\n" + 
			"\"type\":\"text\"\r\n" + 
			"},\r\n" + 
			"{\r\n" + 
			"\"text\":\"Galerias Test Plantilla\",\r\n" + 
			"\"type\":\"text\"\r\n" + 
			"}\r\n" + 
			"]\r\n" + 
			"}\r\n" + 
			"]\r\n" + 
			"},\r\n" + 
			"\"to\":\"50371540255\",\r\n" + 
			"\"token\":\"unt40fXZO0FxRYlDC9ewq6ONAK\"\r\n" + 
			"}\r\n" + 
			"";
	
	public static void main(String[] args)  {
		BasicCookieStore cookieStore = new BasicCookieStore(); 
		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCookieStore(cookieStore).build(); 
		HttpPost postRequest = new HttpPost("https://tickets.bitworks.com.sv/ApiEnvio/cuenta/Login?usuario=SimanEnvios&contrasena=9nZ9FNE3");
		postRequest.setHeader("Content-Type", "application/x-www-form-urlencoded");
		postRequest.setHeader("tiporequest", "movil");
		
		try {
		
		CloseableHttpResponse response = httpclient.execute(postRequest);
		List<Cookie> cookies = cookieStore.getCookies();
		response.close();
		
		StringEntity se = new StringEntity(payLoadLogin); 
		se.setContentType("application/json");
		
		HttpPost httpPost = new HttpPost("https://tickets.bitworks.com.sv/ApiEnvio/Whatsapp/EnviarMensaje");
		httpPost.setHeader("Content-Type", "application/json");
		httpPost.setHeader("Host", "tickets.bitworks.com.sv");
		httpPost.setEntity(se);
		CloseableHttpResponse response2 = httpclient.execute(httpPost);
		
		String bodyJson2 = IOUtils.toString(response2.getEntity().getContent(), "UTF-8");
		System.out.println(bodyJson2);
		response2.close();
		}catch(Exception ex) {
			
			ex.printStackTrace();
			
		}
			
		
	}

}
