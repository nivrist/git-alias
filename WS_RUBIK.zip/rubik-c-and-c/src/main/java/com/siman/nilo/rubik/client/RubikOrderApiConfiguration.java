package com.siman.nilo.rubik.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.siman.nilo.rubik.repository.AlsParamCandCRepository;


import feign.RequestInterceptor;
import feign.RequestTemplate;


public class RubikOrderApiConfiguration implements RequestInterceptor {

	
	@Override
	public void apply(RequestTemplate template) {
		
	}
}
